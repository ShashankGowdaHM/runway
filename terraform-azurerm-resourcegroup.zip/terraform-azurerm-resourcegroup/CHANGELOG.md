# Changelog

# 1.1

- Update codeway to use `runway-terraform-module-v2` template
- Add `terraform-docs` configuration file
- Add instructions to update module documentation via `update-docs.sh` script

# 1.0

- Create `sample` module and examples
- Migrate to Terraform 0.13
