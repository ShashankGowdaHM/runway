# Provisioning Policy Module

This folder contains a [Terraform](https://www.terraform.io/) module that creates an IAM policy document following the least privilege principle to define the required permissions to create, update and destroy the resources described in the collection of modules available in this repository. 

## How to use this module?

Used either in other Runway modules to compose new policies or in conjunction with the [runway-role](https://github.azc.ext.hp.com/runway/terraform-aws-iam/tree/master/modules/runway-role) to create an IAM role ready for provisioning Runway modules via Codeway pipelines.

## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:-----:|
| create\_integration\_tests\_policy | Flag to enable or disable creating supplementary policies for testing this module. | `bool` | `false` | no |
| create\_policy | Flag to enable or disable creating the provisioning policy. | `bool` | `true` | no |
| name\_prefix | The name prefix used by the services managed by the policies. | `string` | n/a | yes |
| policy\_path | IAM policy path. | `string` | `"/runway/"` | no |
| role\_path | IAM role path. | `string` | `"/runway/"` | no |

## Outputs

| Name | Description |
|------|-------------|
| policy\_arn | The policy ARN. |
| policy\_document | The policy document in JSON format. |

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_roles"></a> [roles](#module\_roles) | git::ssh://git@github.azc.ext.hp.com/runway-incubator/terraform-azurerm-authorization//modules/resource-group-roles/ | v0.1.4 |

## Resources

| Name | Type |
|------|------|
| [azurerm_resource_group.rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_contributors"></a> [contributors](#input\_contributors) | List of email addresses for users to be assigned the Contributor role. | `list(string)` | `[]` | no |
| <a name="input_location"></a> [location](#input\_location) | The location of the resource group | `string` | n/a | yes |
| <a name="input_owners"></a> [owners](#input\_owners) | List of email addresses for users to be assigned the Owner role. | `list(string)` | n/a | yes |
| <a name="input_readers"></a> [readers](#input\_readers) | List of email addresses for users to be assigned the Reader role. | `list(string)` | `[]` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group | `string` | n/a | yes |
| <a name="input_scope_subscription_id"></a> [scope\_subscription\_id](#input\_scope\_subscription\_id) | The subscription ID where roles will be assigned. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to assign to the resource group | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_location"></a> [location](#output\_location) | The location of the resource group |
| <a name="output_name"></a> [name](#output\_name) | The name of the resource group |
| <a name="output_resource_group_tags"></a> [resource\_group\_tags](#output\_resource\_group\_tags) | A mapping of tags assigned to the Resource Group |
<!-- END_TF_DOCS -->