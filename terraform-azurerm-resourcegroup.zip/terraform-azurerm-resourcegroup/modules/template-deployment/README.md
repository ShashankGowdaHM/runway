# Azure Resource Group Template Deployment Terraform Module

This module deploys an Azure Resource Group template using the `azurerm_resource_group_template_deployment` resource.

## Inputs

- `deployment_name`: The name of the deployment.
- `resource_group_name`: The name of the resource group where the template is deployed.
- `template_content`: The ARM template content.
- `parameters_content`: The ARM template parameters in JSON format.
- `tags`: Tags for the deployment (map of string).
- `deployment_mode`: Deployment mode (Incremental or Complete).
- `location`: The location of the resource group.

## Outputs

- `deployment_name`: The name of the deployment.
- `deployment_id`: The ID of the deployment.
- `deployment_status`: The provisioning status of the deployment.

## Example Usage

```hcl
terraform {
  # Check releases for updates in this module
  source = "git::ssh://git@github.azc.ext.hp.com/runway-incubator//terraform-azurerm-resourcegroup.git//modules/template-deployment
?ref=v0.1.3"
}

include {
  path = find_in_parent_folders()
}

inputs = {
  deployment_name     = "my-deployment"
  resource_group_name = "my-resource-group"
  template_content    = file("template.json")
  parameters_content = file("parameters.json")
  deployment_mode     = "Incremental"
  location            = "East US"
  tags = {
    "Environment" = "Production"
  }
}
```

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_resource_group_template_deployment.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_deployment_mode"></a> [deployment\_mode](#input\_deployment\_mode) | The deployment mode (Incremental or Complete) | `string` | `"Incremental"` | no |
| <a name="input_deployment_name"></a> [deployment\_name](#input\_deployment\_name) | The name of the deployment | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The location of the resource group | `string` | `"East US"` | no |
| <a name="input_parameters_content"></a> [parameters\_content](#input\_parameters\_content) | The ARM template parameters in JSON format | `string` | `"{}"` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for the deployment | `map(string)` | `{}` | no |
| <a name="input_template_content"></a> [template\_content](#input\_template\_content) | The ARM template content | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_deployment_id"></a> [deployment\_id](#output\_deployment\_id) | The ID of the deployment |
| <a name="output_deployment_name"></a> [deployment\_name](#output\_deployment\_name) | The name of the deployment |
<!-- END_TF_DOCS -->
