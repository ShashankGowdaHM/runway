package test

import (
	"testing"
)

func resourceGroupTest(t *testing.T) {
	t.Parallel()
}
