package test

import (
	"testing"
)

func TestTerraformModules(t *testing.T) {
	t.Parallel()

	testCases := []struct {
		name     string
		testCode func(*testing.T)
	}{
		{"ResourceGroupTest", resourceGroupTest},
	}

	t.Run("group", func(t *testing.T) {
		for _, testCase := range testCases {
			// To avoid the range variable from getting updated in the parallel tests,
			// we bind a new name that is within the scope of the for block.
			testCase := testCase

			t.Run(testCase.name, func(t *testing.T) {
				testCase.testCode(t)
			})
		}
	})
}
