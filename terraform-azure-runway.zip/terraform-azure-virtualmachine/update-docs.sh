#!/bin/sh

echo "Updating repository documentation..."
for m in `ls -d modules/*/`
do
  echo "Running terraform-docs on $m"
  terraform-docs $m -c resources/terraform-docs/config.yaml
done
