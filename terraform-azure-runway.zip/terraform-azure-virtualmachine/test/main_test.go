package test

import (
	"os"
	"testing"

	helpers "github.azc.ext.hp.com/runway/terratest-lib/v2"
)

func TestMain(m *testing.M) {
	// Test environment setup
	// Create IAM provisioning account using the module's provisioning policy
	user := helpers.NewIamUser("resources/provisioning-policy", true)
	originalCreds := user.Set()

	exitCode := m.Run()

	// Tear down test environment
	// Unset and destroy the IAM provisioning account
	user.Unset(originalCreds)
	user.Destroy()
	os.Exit(exitCode)
}
