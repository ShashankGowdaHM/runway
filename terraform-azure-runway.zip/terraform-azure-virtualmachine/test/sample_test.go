package test

import (
	"os"
	"regexp"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"

	helpers "github.azc.ext.hp.com/runway/terratest-lib/v2"
	aws_terratest "github.com/gruntwork-io/terratest/modules/aws"
	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
)

func TestCreateSampleInstance(t *testing.T) {
	t.Parallel()
	helpers.CheckRequiredVariables(t, []string{
		"TF_VAR_region",
		"TF_VAR_subnet_id",
	})

	region := os.Getenv("TF_VAR_region")
	subnetID := os.Getenv("TF_VAR_subnet_id")

	terraformOptions := &terraform.Options{
		TerraformDir: test_structure.CopyTerraformFolderToTemp(t, "../", "examples/create-sample"),

		// Variables to pass to our Terraform code using -var options
		Vars: map[string]interface{}{
			"region":    region,
			"subnet_id": subnetID,
		},

		// Disable colors in Terraform commands so its easier to parse stdout/stderr
		NoColor: true,
	}

	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)

	// Get module outputs
	privateIP := terraform.Output(t, terraformOptions, "private_ip")
	instanceID := terraform.Output(t, terraformOptions, "instance_id")

	// Check if the output is a valida IP Address
	ipRegex, _ := regexp.Compile(`^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$`)
	assert.Regexp(t, ipRegex, privateIP)

	// You can also use terratest aws helper methods to do extra validations
	ipFromEc2 := aws_terratest.GetPrivateIpOfEc2Instance(t, instanceID, region)
	assert.Equal(t, ipFromEc2, privateIP)
}
