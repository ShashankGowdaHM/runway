# Contributors' Guide

Contributions are very welcome! We follow a fairly standard pull request process for contributions, subject to the following guidelines:

1. File a GitHub issue
1. Create a branch
1. Make your changes
1. Push your branch
1. Create a pull request
1. Wait for the review and pull request merge

## Code of Conduct

Please refer to this [document](CODE_OF_CONDUCT.md).
