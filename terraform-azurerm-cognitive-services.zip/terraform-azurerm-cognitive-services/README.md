# Azure Tenant IAM Entities

## Best practieces

 - Have a maximum of 5 global admins
 - Have all users access the tenant using a federated user.
 - Scope user access at the subscription level using a role assignment. Suggestted role assignment are:
   - Owner
   - Contributor
   - Reader

   https://learn.microsoft.com/en-us/azure/role-based-access-control/best-practices